import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import LabelEncoder


# Load data
data = pd.read_csv("dataset_50.csv")
label_encoder = LabelEncoder()
data['backend_code'] = label_encoder.fit_transform(data['backend_name'])
# Split data into features and target
X = data[['mapomatic_score', 'num_qubits', 'backend_code']]
y = data['exp_val']

# Model training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

linear_regressor = LinearRegression()
linear_regressor.fit(X_train, y_train)

svr_regressor = SVR()
svr_regressor.fit(X_train, y_train)

gb_regressor = GradientBoostingRegressor(random_state=42)
gb_regressor.fit(X_train, y_train)



# Train a linear regression model
regressor = LinearRegression()
regressor.fit(X, y)

# simulator data
simulator = pd.read_csv("simulator2.csv")
X2 = np.array(simulator['num_qubits']).reshape(-1, 1)
y2 = simulator['exp_val']

# Model training
X_train2, X_test2, y_train2, y_test2 = train_test_split(X2, y2, test_size=0.2, random_state=42)

linear_regressor2 = LinearRegression()
linear_regressor2.fit(X_train2, y_train2)

svr_regressor2 = SVR()
svr_regressor2.fit(X_train2, y_train2)

gb_regressor2 = GradientBoostingRegressor(random_state=42)
gb_regressor2.fit(X_train2, y_train2)


# Streamlit UI
st.title('Quantum Expectation Value Predictor')

st.sidebar.header('Input Parameters')
backend_name = st.sidebar.selectbox('Select Backend', data['backend_name'].unique())
mapomatic_score = st.sidebar.number_input('Mapomatic Score', min_value=0.0, max_value=1.0, value=0.5)
num_qubits = st.sidebar.slider('Number of Qubits', min_value=3, max_value=7, value=5)
backend_code = label_encoder.transform([backend_name])[0]

# Predict using selected model
selected_regressor = st.sidebar.radio('Select Model', ('Linear Regression', 'SVR', 'Gradient Boosting'))
if selected_regressor == 'Linear Regression':
    regressor = linear_regressor
    reg = linear_regressor2
elif selected_regressor == 'SVR':
    regressor = svr_regressor
    reg = svr_regressor2
else:
    regressor = gb_regressor
    reg = gb_regressor2

# Prediction
prediction = regressor.predict([[mapomatic_score, num_qubits, backend_code]])[0]
prediction = round(prediction, 3)
# Display result
st.write(f'Expected Value for Backend {backend_name}: {prediction}')

pred = reg.predict([[num_qubits]])[0]
pred = round(pred, 3)
# Display result
st.write(f'Expected Value for Qasm_simulator: {pred}')