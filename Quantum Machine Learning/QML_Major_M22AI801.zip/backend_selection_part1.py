import numpy as np
import mapomatic as mm
import pandas as pd
import warnings

warnings.filterwarnings("ignore")

from qiskit import QuantumCircuit, Aer, transpile, execute
from qiskit.circuit import Parameter
from qiskit.circuit.library import TwoLocal, EfficientSU2
from qiskit_ibm_runtime.fake_provider import FakeProvider
from qiskit.utils import QuantumInstance, algorithm_globals
from qiskit.algorithms import VQE
from qiskit.algorithms.optimizers import COBYLA
from qiskit.opflow import I, X, Z, PauliSumOp


fake_provider = FakeProvider()

def create_circuit(n, backend):

    H = 0 * (I ^ n)

    # Constants for the Hamiltonian
    J = 1.2  # Coupling constant for ZZ interaction
    h = 0.7  # Transverse field strength
    
    # Add nearest-neighbor ZZ interactions
    for i in range(n - 1):
        # Initialize a term with identity operators
        if i == 0:
            zz_term = Z ^ Z ^ (I ^ (n - 2))
        elif i == n - 2:
            zz_term = (I ^ (n - 2)) ^ Z ^ Z
        else:
            zz_term = (I ^ i) ^ (Z ^ Z) ^ (I ^ (n - i - 2))

        H += J * zz_term

    # Add transverse field term (X) to each qubit
    for i in range(n):
        if i == 0:
            x_term = X ^ (I ^ (n - 1))
        elif i == n - 1:
            x_term = (I ^ (n - 1)) ^ X
        else:
            x_term = (I ^ i) ^ X ^ (I ^ (n - i - 1))

        H += h * x_term

    ansatz = TwoLocal(
            num_qubits=n,
            rotation_blocks=['ry', 'rz'],
            entanglement_blocks='cz',
            entanglement='full',
            reps=3
        )
    optimizer = COBYLA(maxiter=250)
    vqe = VQE(ansatz, optimizer, quantum_instance=backend)
    
    result = vqe.compute_minimum_eigenvalue(H)
    qc = ansatz.bind_parameters(result.optimal_point)
    
    return qc


n = 5
backends = fake_provider.backends()
backends = [backend for backend in backends if backend.configuration().n_qubits >= n]

mm_results = {}
for backend in backends:
    try:
        print("---------------------------------------------")
        print(backend)

        print("Getting Circuit")
        qc = create_circuit(n, backend)
        print("Got Circuit")

        # Transpile the ideal circuit to a circuit that can be directly executed by the backend
        tc = transpile(qc, backend)

        small_qc = mm.deflate_circuit(tc)
        layouts = mm.matching_layouts(small_qc, backend)
        scores = mm.evaluate_layouts(small_qc, layouts, backend)

        mm_results[backend.name()] = scores[0][1]
        
        print(mm_results)

    except Exception:
        continue
        
print("MAPOMATIC RESULTS")
print(mm_results)
        
        
exp_val = {}

for backend_name in mm_results.keys():
    try:
        print("==========================================")
        print(backend)
        backend = fake_provider.get_backend(backend_name)

        print("Getting Circuit")
        qc = create_circuit(n, backend)
        print("Got Circuit")

        tc = transpile(qc, backend)

        # Simulate the circuit
        shots = 1024
        tc.measure_all()
        job = execute(tc, backend, shots=shots)
        result = job.result()
        counts = result.get_counts()

        # Normalize the counts to get probabilities
        total_counts = sum(counts.values())
        probabilities = {state: count / total_counts for state, count in counts.items()}

        # Expected probabilities for a uniform distribution
        expected_probabilities = {format(i, '0' + str(n) + 'b'): 1/2**n for i in range(2**n)}

        # Calculate total variation distance
        tvd = sum(abs(probabilities.get(state, 0) - expected) for state, expected in expected_probabilities.items()) / 2

        exp_val[backend_name] = tvd
        
        print(exp_val)
        
    except Exception:
        print("ERROR")
        continue

        
print("FINAL RUN")
df = pd.DataFrame()
k1, v1 = [], []

for key, val in mm_results.items():
    k1.extend([key])
    v1.extend([val])

    mm_data = {"backend": k1, "mm_score": v1}
    mm_df = pd.DataFrame(mm_data)

k1, v1 = [], []

for key, val in exp_val.items():
    k1.extend([key])
    v1.extend([val])

exp_data = {"backend": k1, "expval": v1}
exp_df = pd.DataFrame(exp_data)


df = mm_df.merge(exp_df, how='inner', on='backend')
df.to_csv("results_df.csv", index=False)